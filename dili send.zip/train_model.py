# # import pandas as pd
# # from sklearn.model_selection import train_test_split
# # from sklearn.ensemble import RandomForestClassifier
# # from sklearn.metrics import classification_report
# # import joblib

# # # Load the dataset
# # df = pd.read_csv('real_drug_data.csv')

# # # Prepare the data
# # X = df[['Dose1', 'Dose2']]  # Example features
# # y = df['DILI']  # Target variable

# # # Split the data into training and testing sets
# # X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42)

# # # Initialize and train the model
# # model = RandomForestClassifier(n_estimators=100, random_state=42)
# # model.fit(X_train, y_train)

# # # Evaluate the model
# # y_pred = model.predict(X_test)
# # print(classification_report(y_test, y_pred))

# # # Save the model
# # joblib.dump(model, 'dili_model.pkl')
# import pandas as pd
# from sklearn.model_selection import train_test_split, cross_val_score
# from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
# from sklearn.metrics import classification_report, confusion_matrix
# from sklearn.preprocessing import StandardScaler
# import joblib
# import seaborn as sns
# import matplotlib.pyplot as plt

# # Load the dataset
# df = pd.read_csv('real_drug_data.csv')

# # Data Preprocessing
# X = df[['Dose1', 'Dose2']]
# y = df['DILI']

# # Check for missing values
# print("Missing values:\n", df.isnull().sum())

# # Normalize features
# scaler = StandardScaler()
# X_scaled = scaler.fit_transform(X)

# # Split the data into training and testing sets
# X_train, X_test, y_train, y_test = train_test_split(X_scaled, y, test_size=0.3, random_state=42)

# # Initialize and train the model
# model = RandomForestClassifier(n_estimators=100, random_state=42)
# model.fit(X_train, y_train)

# # Evaluate the model
# y_pred = model.predict(X_test)
# print("Classification Report:\n", classification_report(y_test, y_pred))
# print("Confusion Matrix:\n", confusion_matrix(y_test, y_pred))

# # Plot Confusion Matrix
# confusion = confusion_matrix(y_test, y_pred)
# sns.heatmap(confusion, annot=True, fmt='d')
# plt.xlabel('Predicted')
# plt.ylabel('True')
# plt.show()

# # Save the model
# joblib.dump(model, 'dili_model.pkl')





import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import classification_report, confusion_matrix
from sklearn.preprocessing import StandardScaler
import joblib

# Load the dataset
df = pd.read_csv('real_drug_data.csv')

# Prepare the data
X = df[['Dose1', 'Dose2']]
y = df['DILI']

# Normalize features
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# Split the data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X_scaled, y, test_size=0.3, random_state=42)

# Initialize and train the model
model = RandomForestClassifier(n_estimators=100, random_state=42)
model.fit(X_train, y_train)

# Evaluate the model
y_pred = model.predict(X_test)
print(classification_report(y_test, y_pred))
print(confusion_matrix(y_test, y_pred))

# Save the model and scaler
joblib.dump(model, 'dili_model.pkl')
joblib.dump(scaler, 'scaler.pkl')

